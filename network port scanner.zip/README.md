# Multi-threaded Network Port Scanner with GUI

# Description

This project is a Python-based multi-threaded network port scanner with a graphical user interface (GUI). It is designed to scan a target system and identify open ports along with their associated services. The application uses socket programming for network communication and multi-threading to significantly improve scanning speed.

The GUI, built using Tkinter, provides an easy-to-use interface for entering target details, configuring scan parameters, and viewing results in real time.

# Features
Multi-threaded port scanning for faster performance
User-friendly GUI using Tkinter
Real-time display of open ports
Service detection for common ports (HTTP, FTP, SSH, etc.)
Adjustable timeout for scanning
Start/Stop scan functionality
Progress bar and elapsed time tracking
Save scan results to a file
Error handling for invalid inputs

# Technologies Used
Python
Socket Programming (socket)
Multi-threading (threading)
Queue (queue)
Tkinter (GUI)

# Project Structure
port_scanner.py   # Main application file
README.md         # Project documentation

# How to Use
Enter the Target IP address or domain name
Specify Start Port and End Port
Set the Timeout value (default: 0.5 seconds)
Click Start Scan
View open ports in real time
Optionally save results using the Save button

# Example Output
Scanning example.com (93.184.216.34)...

 OPEN---> Port 80 (HTTP)
 OPEN---> Port 443 (HTTPS)
 Scan Completed Successfully!
 
# Future Improvements
Add UDP port scanning
Improve service detection
Export results in CSV/JSON format
Add dark mode UI