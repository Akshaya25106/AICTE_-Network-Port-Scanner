import socket
import threading
import time
import queue
import sys
import tkinter as tk
from tkinter import ttk, messagebox, filedialog

COMMON_PORTS = {
    21: 'FTP', 22: 'SSH', 23: 'Telnet', 25: 'SMTP', 53: 'DNS',
    80: 'HTTP', 110: 'POP3', 143: 'IMAP', 443: 'HTTPS',
    3306: 'MySQL', 3389: 'RDP', 5900: 'VNC', 8080: 'HTTP-Alt'
}

class PortScanner:
    def __init__(self, target, start_port, end_port, timeout=0.5, max_workers=300):
        self.target = target
        self.start_port = start_port
        self.end_port = end_port
        self.timeout = timeout
        self.max_workers = max_workers
        self._stop_event = threading.Event()

        self.total_ports = max(0, end_port - start_port + 1)
        self.scanned_count = 0
        self.open_ports = []
        self._lock = threading.Lock()
        self.result_queue = queue.Queue()

    def stop(self):
        self._stop_event.set()

    def _scan_port(self, port):
        if self._stop_event.is_set():
            return
        try:
            s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            s.settimeout(self.timeout)
            result = s.connect_ex((self.target, port))
            if result == 0:
                service = COMMON_PORTS.get(port, 'Unknown')
                with self._lock:
                    self.open_ports.append((port, service))
                self.result_queue.put(('open', port, service))
            s.close()
        except Exception:
            pass
        finally:
            with self._lock:
                self.scanned_count += 1
            self.result_queue.put(('progress', self.scanned_count, self.total_ports))

    def resolve_target(self):
        return socket.gethostbyname(self.target)

    def run(self):
        sem = threading.Semaphore(self.max_workers)
        threads = []

        for port in range(self.start_port, self.end_port + 1):
            if self._stop_event.is_set():
                break
            sem.acquire()
            t = threading.Thread(target=self._worker_wrapper, args=(sem, port), daemon=True)
            threads.append(t)
            t.start()

        for t in threads:
            t.join()

        self.result_queue.put(('done', None, None))

    def _worker_wrapper(self, sem, port):
        try:
            self._scan_port(port)
        finally:
            sem.release()

class ScannerGUI(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("Advanced Network Port Scanner")
        self.geometry("720x520")

        self.scanner_thread = None
        self.scanner = None
        self.start_time = None
        self.poll_after_ms = 40

        self._build_ui()

    def _build_ui(self):
        frm_top = ttk.LabelFrame(self, text="Scan Settings")
        frm_top.pack(fill="x", padx=10, pady=10)

        ttk.Label(frm_top, text="Target:").grid(row=0, column=0)
        self.ent_target = ttk.Entry(frm_top, width=30)
        self.ent_target.grid(row=0, column=1)

        ttk.Label(frm_top, text="Start Port:").grid(row=0, column=2)
        self.ent_start = ttk.Entry(frm_top, width=10)
        self.ent_start.insert(0, "1")
        self.ent_start.grid(row=0, column=3)

        ttk.Label(frm_top, text="End Port:").grid(row=0, column=4)
        self.ent_end = ttk.Entry(frm_top, width=10)
        self.ent_end.insert(0, "1024")
        self.ent_end.grid(row=0, column=5)

        # NEW: Timeout input
        ttk.Label(frm_top, text="Timeout:").grid(row=1, column=0)
        self.ent_timeout = ttk.Entry(frm_top, width=10)
        self.ent_timeout.insert(0, "0.5")
        self.ent_timeout.grid(row=1, column=1)

        self.btn_start = ttk.Button(frm_top, text="Start Scan", command=self.start_scan)
        self.btn_start.grid(row=1, column=4)

        self.btn_stop = ttk.Button(frm_top, text="Stop", command=self.stop_scan, state="disabled")
        self.btn_stop.grid(row=1, column=5)

        frm_status = ttk.LabelFrame(self, text="Status")
        frm_status.pack(fill="x", padx=10)

        self.var_status = tk.StringVar(value="Idle")
        ttk.Label(frm_status, textvariable=self.var_status).pack(side="left", padx=10)

        self.var_elapsed = tk.StringVar(value="Elapsed: 0.00s")
        ttk.Label(frm_status, textvariable=self.var_elapsed).pack(side="right", padx=10)

        self.progress = ttk.Progressbar(frm_status)
        self.progress.pack(fill="x", padx=10, pady=5)

        frm_results = ttk.LabelFrame(self, text="Open Ports")
        frm_results.pack(fill="both", expand=True, padx=10, pady=10)

        self.txt_results = tk.Text(frm_results)
        self.txt_results.pack(fill="both", expand=True)

        frm_bottom = ttk.Frame(self)
        frm_bottom.pack(fill="x", padx=10)

        ttk.Button(frm_bottom, text="Clear", command=self.clear_results).pack(side="left")
        self.btn_save = ttk.Button(frm_bottom, text="Save", command=self.save_results, state="disabled")
        self.btn_save.pack(side="right")

    def start_scan(self):
        target = self.ent_target.get().strip()
        start_port = int(self.ent_start.get())
        end_port = int(self.ent_end.get())

        try:
            timeout = float(self.ent_timeout.get())
        except:
            messagebox.showerror("Error", "Invalid timeout value")
            return

        self.scanner = PortScanner(target, start_port, end_port, timeout)

        try:
            ip = self.scanner.resolve_target()
            self.append_text(f"Scanning {target} ({ip})...\n\n")
        except:
            messagebox.showerror("Error", "Invalid target")
            return

        self.btn_start.config(state="disabled")
        self.btn_stop.config(state="normal")

        self.start_time = time.time()
        self.var_status.set("Scanning...")

        self.scanner_thread = threading.Thread(target=self.scanner.run, daemon=True)
        self.scanner_thread.start()

        self.after(self.poll_after_ms, self.poll_results)
        self.update_elapsed()

    def stop_scan(self):
        if self.scanner:
            self.scanner.stop()
            self.var_status.set("Stopping...")

    def poll_results(self):
        try:
            while True:
                msg, a, b = self.scanner.result_queue.get_nowait()
                if msg == 'open':
                    self.append_text(f"✔ OPEN → Port {a} ({b})\n")
                elif msg == 'progress':
                    self.progress.config(maximum=b, value=a)
                elif msg == 'done':
                    self.append_text("\n✔ Scan Completed Successfully!\n")
                    self.var_status.set("Done")
                    self.btn_start.config(state="normal")
                    self.btn_stop.config(state="disabled")
                    self.btn_save.config(state="normal")
        except:
            pass

        if self.scanner_thread.is_alive():
            self.after(self.poll_after_ms, self.poll_results)

    def update_elapsed(self):
        if self.start_time:
            elapsed = time.time() - self.start_time
            self.var_elapsed.set(f"Elapsed: {elapsed:.2f}s")
            self.after(200, self.update_elapsed)

    def append_text(self, text):
        self.txt_results.insert(tk.END, text)
        self.txt_results.see(tk.END)

    def clear_results(self):
        self.txt_results.delete("1.0", tk.END)

    def save_results(self):
        file = filedialog.asksaveasfilename(defaultextension=".txt")
        if file:
            with open(file, "w") as f:
                f.write(self.txt_results.get("1.0", tk.END))

def main():
    app = ScannerGUI()
    app.mainloop()

if __name__ == "__main__":
    main()
